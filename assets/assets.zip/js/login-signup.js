$('.login-advance-option-btn').click(function(){
    $('.login-advance-option-area').toggleClass('active');
    $('.login-advance-option-list').slideToggle();
});

