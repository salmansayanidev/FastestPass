$('.login-advance-option-btn').click(function() {
    $('.gene-username-advance-option-area').toggleClass('active');
    $('.username-advance-option-list').slideToggle();
});